//Author Rishab Das
#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <assert.h>

#include <ctype.h>

#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h> 
#define buffer_length 256
int wrap(unsigned, int, int);

int main(int argc, char* argv[argc+1]){
	int w = atoi(argv[1]);

	assert(w > 0);

	struct stat buff;
	int dircheck;
	
	int closed;
	int file; 
	unsigned int width = (unsigned int)w; 
	int check;
	
	if(argc < 3){
		check = wrap(width, 0, 1);
	}
	else{
		dircheck = stat(argv[2], &buff);
		if(dircheck != 0){
			perror("File is not in the directory");
		}

		if(S_ISDIR(buff.st_mode)){
			DIR* dir = opendir(argv[2]);
			struct dirent* ndir;
			do{
				ndir = readdir(dir);
				if(ndir != NULL){

					if(ndir->d_type == 8){
						unsigned long lengthName = strlen(ndir->d_name);
						char* NameFile = malloc(sizeof(char) * (lengthName+5));

						for(int i = 0; i < 5; i++){
							NameFile[i] = ndir->d_name[i];
						}
						int wrapable = strcmp(NameFile, "wrap.");

						if((ndir->d_name[0] != '.') && (wrapable != 0)){
							
							int changedir = chdir(argv[2]);
							if(changedir != 0){
								perror("Directory cannot change");
							}

							file = open(ndir->d_name, O_RDONLY);
							if(file == -1){
								perror("File cannot be opened");
							}

							for(int i = 0; i < lengthName+5; i++){
								if(i == 0){
									NameFile[i] = 'w';
								}
								else if(i == 1){
									NameFile[i] = 'r';
								}
								else if(i == 2){
									NameFile[i] = 'a';
								}
								else if(i == 3){
									NameFile[i] = 'p';
								}
								else if(i == 4){
									NameFile[i] = '.';
								}
								else{
									NameFile[i] = ndir->d_name[i-5];
								}
							}
							int Newfile = open(NameFile, O_RDWR | O_TRUNC | O_CREAT, 0666);
							if(Newfile == -1){
								perror("Destination file cannot be created");
							}

							check = check + wrap(width, file, Newfile);

							closed = close(Newfile);
							if(closed != 0){
								perror("file is not closed\n");
							}
							closed = close(file);
							if(closed != 0){
								perror("file is not closed\n");
							}
							changedir = chdir(".."); //go back to working directory

						}
						free(NameFile);
					}
				}

			}while(ndir != NULL);
			closed = closedir(dir);
			if(closed != 0){
				perror("Directory is not closed\n");
			}
		}
		else{
			if(S_ISREG(buff.st_mode)){
				file = open(argv[2], O_RDONLY);
				if(file == -1){
					perror("File cannot open");
				}
				check = wrap(width, file, 1);
				closed = close(file);
				if(closed != 0){
					perror("File is not closed\n");
				}
			}
		}	
	}
	
	if(check != 0){
		perror("Word exceeds width\n");
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

int wrap(unsigned width, int input_df, int output_fd){

	char space[1]; 
	space[0] = ' ';
	char newline[1]; 
	newline[0] = '\n';
	ssize_t r; 
	int lengthWord = 0; 
	int guide = 0;
	int line = 0;
    char buffer[buffer_length]; 
	char* word = malloc(sizeof(char) * 2);
	int new_line = 0; 
	int newline_count = 0; 
	int ret = 0; 
	int len = 2;
	do{
		r = read(input_df, buffer, buffer_length);

		for(int i=0; i<r; i++){
			
			if(isspace(buffer[i]) == 0){
				if(newline_count >= 2){
					write(output_fd, newline, 1);
					write(output_fd, newline, 1);
					new_line = 0;
					line = 0;
				}
				newline_count = 0;
				if(guide < len){
					word[guide] = buffer[i];
					guide++;
					lengthWord++;
				}
				else{
					len = len*2;
					char *q = realloc(word, sizeof(char) * (len));
					if (!q) return 1;
					word = q;
					word[guide] = buffer[i];
					guide++;
					lengthWord++;
				}
			}
			else{  
				if(lengthWord != 0){
					line = line + lengthWord;
					if(new_line != 0){
						line++; 
						if(line > width){
							if(lengthWord > width){
								write(output_fd, newline, 1);
								write(output_fd, word, lengthWord);
								write(output_fd, newline, 1);
								new_line = 0;
								line = 0;
								ret = -1;
								
							}
							else{
								write(output_fd, newline, 1);
								write(output_fd, word, lengthWord);
								line = lengthWord;
							}
							lengthWord = 0;
							guide = 0;
						}
						else{
							write(output_fd, space, 1);
							write(output_fd, word, lengthWord);
							lengthWord = 0;
							guide = 0;
						}
					}
					else{
						if(line > width){
							write(output_fd, word, lengthWord);
							write(output_fd, newline, 1);
							lengthWord = 0;
							guide = 0;
							new_line = 0;
							ret = -1;
							line = 0;
						}
						else{
							write(output_fd, word, lengthWord);
							lengthWord = 0;
							guide = 0;
							new_line = 1;
						}
					}
				}		
				if(buffer[i] == '\n'){
					newline_count++;
				}
			}
		}
	}while(r != 0);

	if(lengthWord != 0){
		line = line + lengthWord;

		if(new_line != 0){
			line++; 
			if(line > width){
				if(lengthWord > width){
					write(output_fd, newline, 1);
					write(output_fd, word, lengthWord);
					write(output_fd, newline, 1);
					new_line = 0;
					ret = -1;
					line = 0;
				}
				else{
					write(output_fd, newline, 1);
					write(output_fd, word, lengthWord);
					write(output_fd, newline, 1);
					line = lengthWord;
				}
				lengthWord = 0;
				guide = 0;
			}
			else{
				write(output_fd, space, 1);
				write(output_fd, word, lengthWord);
				write(output_fd, newline, 1);
				lengthWord = 0;
				guide = 0;
			}
		}
		else{
			if(line > width){
				write(output_fd, word, lengthWord);
				write(output_fd, newline, 1);
				lengthWord = 0;
				guide = 0;
				new_line = 0;
				ret = -1;
				line = 0;
			}
			else{
				write(output_fd, word, lengthWord);
				write(output_fd, newline, 1);
				lengthWord = 0;
				guide = 0;
				new_line = 1;
			}
		}
	}
	free(word);
	return ret;
}